__author__ = 'reem'

# constants

WEBCAM_ID = 1
TIME_FOR_CAPTURE_CIRCLE = 30 * 1000 # in ms
NUMBER_OF_PREVIEW_PICS = 5
DIM_PREVIEW_WIDTH = 160
DIM_PREVIEW_HEIGHT = 120
SIZE_PREVIEW = (DIM_PREVIEW_WIDTH, DIM_PREVIEW_HEIGHT)
PATH_PROPERTY_CUR_ID = "extra_files/current_avail_id"
PATH_BLANK_PICTURE = "extra_files/blank.jpg"
PATH_MUSEUM_LOGO = "extra_files/mada_jerusalem_logo_COLOR_WIDE_WEB.png"
DIM_MUSEUM_LOGO_HEIGHT = 99


# lambda functions
get_picture_path = lambda pic_id : "pic/" + str(pic_id) + ".jpg"
