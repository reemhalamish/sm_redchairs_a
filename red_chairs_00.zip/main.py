from mercurial.pathutil import pathauditor

__author__ = 'reem'


import Tkinter as tk
import cv2
import cv2.cv as cv
from PIL import Image, ImageTk
from constants import *
from previewPicture import PreviewPicture



current_image = None
current_id = 0

width, height = 800, 600 # for the main stream on the screen
cap = cv2.VideoCapture(WEBCAM_ID)
cap.set(cv.CV_CAP_PROP_FRAME_WIDTH, width)
cap.set(cv.CV_CAP_PROP_FRAME_HEIGHT, height)

root = picture_streaming_label = preview_frame = None
preview_pics_canvases = []

def init():
    global current_id, root, picture_streaming_label, preview_pics_canvases, preview_frame


    # load next id
    f = open(PATH_PROPERTY_CUR_ID, "r")
    current_id = int(f.readline())
    f.close()

    #                   ~*~ make the tkinter window look well ~*~
    # root
    root = tk.Tk()
    root.bind('<Escape>', lambda e: root.quit())

    # streaming
    picture_streaming_label = tk.Label(root)
    picture_streaming_label.grid(row = 0, column = 0, sticky = 'NW')

    # FIFO of thunbnails
    preview_frame = tk.Frame(root)
    preview_frame.grid(row = 0, column = 1, sticky = 'NE')
    w,h = SIZE_PREVIEW
    img = Image.open(PATH_BLANK_PICTURE)
    resized = img.resize(SIZE_PREVIEW, Image.ANTIALIAS)
    imgtk = ImageTk.PhotoImage(resized)
    img.close()


    for index in range(NUMBER_OF_PREVIEW_PICS):
        # pic_canvas = tk.Canvas(preview_frame, bd=10, highlightthickness=0, height = h, width = w)
        # pic_canvas.configure(scrollregion= (-(w//2), -(h//2), (w//2), (h//2)))
        # pic_canvas.create_image(0, 0, image=imgtk, tags = "IMG")
        # pic_canvas.grid(row = index, column = 0, sticky = 'N')
        # preview_pics_canvases.append([pic_canvas, imgtk])
        pic_canvas = PreviewPicture(master = preview_frame, preview_id=index, bd=10, highlightthickness=0, height = h, width = w)
        pic_canvas.grid(row = index, column = 0, sticky = 'N')
        preview_pics_canvases.append(pic_canvas)

    for img_id, preview_canvas in zip(reversed(range(current_id)), reversed(preview_pics_canvases)):
        print "img_id is", img_id
        preview_canvas.showImageFromId(img_id)


    # remind the GUI to start taking snapshots
    picture_streaming_label.after(50, take_snapshot)





def show_frame():
    global current_image, picture_streaming_label
    _, frame = cap.read()
    frame = cv2.flip(frame, 1)
    cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
    img = Image.fromarray(cv2image)
    imgtk = ImageTk.PhotoImage(image=img)
    picture_streaming_label.imgtk = imgtk
    picture_streaming_label.configure(image=imgtk)
    picture_streaming_label.after(50, show_frame)
    current_image = frame

def take_snapshot():
    global current_image, current_id

    picture_streaming_label.after(TIME_FOR_CAPTURE_CIRCLE, take_snapshot)

    if current_image == None: return

    # save as file
    filename = get_picture_path(current_id)
    cv2.imwrite(filename,current_image)

    # save the museum logo above
    background = Image.open(filename)
    foreground = Image.open(PATH_MUSEUM_LOGO)

    bw, bh = background.size
    posy = max(0, bh - DIM_MUSEUM_LOGO_HEIGHT) # put the logo on the bottom of the picture
    posx = 0
    background.paste(foreground, (posx,  posy), foreground)
    background.save(filename)


    print filename

    # update it on the screen
    update_picture_added(current_id) # last picture taken

    # update the variable for the next new file
    current_id += 1

    # save the variable globally in case of an emergency poweroff
    with open(PATH_PROPERTY_CUR_ID, "w") as f:
        f.write(str(current_id))


'''
    will make most of the canvases to show the the previous canvas did before,
    the last canvas will print the new picture
'''
def update_picture_added(picture_id):
    global preview_pics_canvases
    w,h = SIZE_PREVIEW

    for index in range(NUMBER_OF_PREVIEW_PICS - 1): # without the last one
        fr_canvas = preview_pics_canvases[index]
        sc_canvas = preview_pics_canvases[index + 1]
        fr_canvas.mirrorizeOtherPP(sc_canvas)

    canvas = preview_pics_canvases[-1] # last one
    canvas.showImageFromId(picture_id)




    pass # TODO: continue


init()
show_frame()
root.mainloop()